#include "Arduino.h"
#include "draw.h"
#include "charset.h"

//write Pixel WPixelIndex to Wbank with color Wcolor
#define WritePixel(WPixelIndex,WBank,Wcolor) _Image[WPixelIndex] = (WBank) ? ( (_Image[WPixelIndex] & 0x0F) | (Wcolor<<4)) : ((_Image[WPixelIndex] & 0xF0) | Wcolor )
    
// constructor for the draw object
Draw::Draw(byte* ImageBuffer, byte PixelsPerRow, int PixelsTotal)
{
  _Image= ImageBuffer;
 _PixelsPerRow=PixelsPerRow;                 
 _PixelsTotal=PixelsTotal; 
  ClearBank(0);
  ClearBank(1);
  randomSeed(1);
 }

void Draw::DrawPoint(byte X, byte Y, byte color, bool Bank)
{
int i = Y * _PixelsPerRow + X;
WritePixel(i,Bank,color);
}

void Draw::DrawRectangle(byte X0, byte Y0 , byte X1 , byte Y1, bool filled , byte color, bool Bank)
{
  byte x,y;
  for (x=X0;x<=X1;x++)   
  {
    for (y=Y0;y<=Y1;y++) 
    { 
     int i = y * _PixelsPerRow + x;
     WritePixel(i,Bank,color);
     if ((!filled)&& y!=Y1 && ((x!=X0) && (x!=X1))) y=Y1-1;
    }
   }
}

// draw a string in the buffer. X specifies the starting pixel ( e.g. x=10 means the text starts at the third pixel of the second character. )
void Draw::PrintString(int X, char * s, byte color, bool Bank)
{ 
  int CharIndex = X / 7;  // start at first character that should be ( partially ) displayed
  byte c; 
  if (CharIndex<strlen(s))
    while ( s[CharIndex] && ( (CharIndex)*7-X < _PixelsPerRow )) {
    if (color) c=color; else c=(CharIndex % 7)+1; // if color=0 cycle through all colors
    PrintChar(CharIndex * 7 - X, s[CharIndex],c,Bank);
    CharIndex++;
  }
}

void Draw::ClearSnake()
{
_SnakeCount=0;
_SnakeOldest=0;
}

void Draw::ClearBank(bool Bank)
{
  if (!Bank) {for (int i = 0 ; i < _PixelsTotal; i++ ) _Image[i]&= 0xF0;}
        else {for (int i = 0 ; i < _PixelsTotal; i++ ) _Image[i]&= 0x0F;}  
}

// move head of snake to new position, remove tail of snake . Redraw snake
void Draw::UpdateSnake(bool Bank)
{
 _SnakeX+=_SnakeVx; _SnakeY+=_SnakeVy; //  snakeX/Y unit : 1/256 pixels. SnakeVx/y unit : (1/256 pixels )/ disk rotation
 if (_SnakeX >= 256*120 ) { _SnakeX=256*120;  _SnakeVx = -random(150,800);} // bounce right side, pick new speed
 if (_SnakeX <= 256*5 )   { _SnakeX=256*5;    _SnakeVx = random(150,800); } // bounce left side, pick new speed
 if (_SnakeY >= 256*7 )   { _SnakeY=256*7;    _SnakeVy = -random(50,256); } // bounce top side, pick new speed
 if (_SnakeY <= 0 )       { _SnakeY=0;        _SnakeVy = random(50,256);  } // bounce bottom side, pick new speed
 AddSnakePosition(_SnakeX>>8,_SnakeY>>8, Ccyan); // add the new point the the snake
 DrawSnake(Bank);
}

// internal functions

void Draw::PrintChar(int X, byte ch, byte color, bool Bank)
{
  int kol,row;
  for (row = 0; row < 8; row++) for (kol = 0; kol < 7; kol++)
    { byte z = pgm_read_byte_near(&(charset[ch - 32][row]));
       if ( ( ((6 - kol) + X) < _PixelsPerRow) && ((6-kol)+X >=0) ) 
         { byte b = (z & (1 << kol));            
           int  i = row * _PixelsPerRow + (6 - kol) + X;
           if (b) b=color; else b=0;  
           WritePixel(i,Bank,b);
         } 
    } 
}

void Draw::AddSnakePosition(byte X , byte Y, byte color)
{
if (_SnakeCount<_SnakeSize) 
{ // snake is not complete -> only add segment
  _SnakePositions[_SnakeCount].X=X; 
  _SnakePositions[_SnakeCount].Y=Y; 
  _SnakePositions[_SnakeCount].Color=color;
  _SnakeCount++;
} else
{ // snake is complete replace oldest segment with new
  _SnakePositions[_SnakeOldest].X=X;   
  _SnakePositions[_SnakeOldest].Y=Y;   
  _SnakePositions[_SnakeOldest].Color=color;
  _SnakeOldest++; if (_SnakeOldest>=_SnakeSize) _SnakeOldest=0; 
} 
}

void Draw::DrawSnake(bool Bank)
{
  for (byte i=0; i<_SnakeCount;i++) DrawPoint(_SnakePositions[i].X,_SnakePositions[i].Y,_SnakePositions[i].Color ,Bank);
}





