#ifndef Draw_h
#define Draw_h

// Defines a class that provides several functions to fill a pixelbuffer with text, animations.

#include "Arduino.h"

#define Cblack   0
#define Cred     1
#define Cgreen   2
#define Cyellow  3
#define Cblue    4
#define Cmagenta 5
#define Ccyan    6
#define Cwhite   7

class Draw
{
  public:
    Draw(byte* ImageBuffer, byte PixelsPerRow, int PixelsTotal);    
    void Draw::DrawPoint(byte X, byte Y, byte color, bool Bank);
    void Draw::DrawRectangle(byte X0, byte Y0 , byte X1 , byte Y1, bool filled , byte color, bool Bank);
    void Draw::PrintString(int X, char * s, byte color, bool Bank);  
    void Draw::ClearSnake();    
    void Draw::ClearBank(bool Bank);
    void Draw::UpdateSnake(bool Bank);
    
  private:
    void Draw::PrintChar(int X, byte ch, byte color, bool Bank);
    void Draw::AddSnakePosition(byte X , byte Y, byte color);
    void Draw::DrawSnake(bool Bank);
    byte* _Image;       // pointer to the image buffer
    byte _PixelsPerRow;                  
    int  _PixelsTotal; 
    // snake related date
    #define _SnakeSize 20   // max number of pixels in the snake
    char _SnakeCount=0;
    char _SnakeOldest=0;
    int _SnakeX=0,_SnakeY=0,_SnakeVx=256,_SnakeVy=128;    
    
    typedef struct { byte X ; byte Y ; byte Color; } _SnakeElement;
    _SnakeElement _SnakePositions[_SnakeSize];
};
#endif
